# Meenakshi-inspired Anniversary Scrollytelling Site

Open `index.html` in a browser.

The opening is scroll-controlled:
- Temple-inspired hero
- Ornate split doors
- Doors open left/right as the visitor scrolls
- Golden reveal
- Wedding/memory chapters
- Timeline
- Family message
- Anniversary ending

To personalize:
1. Replace the placeholder photo cards with your brother and sister-in-law's photos.
2. Edit the names, dates and memories in `index.html`.
3. If you want music, add an audio file and a user-triggered play button (autoplay is restricted by browsers).

The temple opening is an original stylized illustration inspired by South Indian temple architecture rather than a manipulated photograph of the actual temple.
